/**
 * PITCHSIDE — Stadium Companion for FIFA World Cup 2026
 * app.js
 *
 * Pure/testable logic lives at the top (exported for unit tests).
 * DOM wiring lives at the bottom, guarded so this file can be safely
 * `require()`-d in a Node test runner without a DOM present.
 */

/* ------------------------------------------------------------------ */
/* 1. CONFIG                                                          */
/* ------------------------------------------------------------------ */

const CONFIG = {
  MAX_MESSAGE_LENGTH: 500,       // caps payload size -> limits API cost/abuse
  MAX_TOKENS: 400,
  MODEL: "claude-sonnet-4-6",
  REQUEST_TIMEOUT_MS: 20000,
  STORAGE_KEY: "pitchside_key",
};

const SYSTEM_PROMPT_BASE = `You are Pitchside, an on-site GenAI assistant for fans, organizers, volunteers, and venue staff during the FIFA World Cup 2026. You help with:
- Navigation inside and around the stadium
- Crowd management and congestion guidance
- Accessibility support for fans with disabilities
- Transportation and parking guidance
- Sustainability practices at the venue
- Multilingual assistance
- Operational intelligence and real-time decision support for staff

Always answer helpfully, concretely, and briefly (3-6 sentences or a short list). Invent specific, plausible stadium details (gate letters, section numbers, shuttle lines, timings) when needed to make the answer concrete and useful, since this is a demo scenario, not a live feed. Never say you lack real-time data — instead give a confident, realistic, specific answer in the spirit of the demo.
Respond ONLY in this language: `;

/* ------------------------------------------------------------------ */
/* 2. PURE / TESTABLE HELPERS                                         */
/* ------------------------------------------------------------------ */

/**
 * Validates a raw API key string before it's stored or used.
 * @param {string} key
 * @returns {{ valid: boolean, reason?: string }}
 */
function validateApiKey(key) {
  if (typeof key !== "string" || key.trim().length === 0) {
    return { valid: false, reason: "empty" };
  }
  const trimmed = key.trim();
  if (!trimmed.startsWith("sk-ant-")) {
    return { valid: false, reason: "format" };
  }
  if (trimmed.length < 20) {
    return { valid: false, reason: "too_short" };
  }
  return { valid: true };
}

/**
 * Validates a user chat message: non-empty, within length limits,
 * and free of characters that don't belong in a plain-text message.
 * @param {string} text
 * @returns {{ valid: boolean, reason?: string }}
 */
function validateMessage(text) {
  if (typeof text !== "string") return { valid: false, reason: "type" };
  const trimmed = text.trim();
  if (trimmed.length === 0) return { valid: false, reason: "empty" };
  if (trimmed.length > CONFIG.MAX_MESSAGE_LENGTH) {
    return { valid: false, reason: "too_long" };
  }
  return { valid: true };
}

/**
 * Strips control characters that have no place in a chat message
 * (defense-in-depth; DOM insertion already uses textContent, never innerHTML).
 * @param {string} text
 * @returns {string}
 */
function sanitizeText(text) {
  // eslint-disable-next-line no-control-regex
  return text.replace(/[\u0000-\u0008\u000B\u000C\u000E-\u001F]/g, "").trim();
}

/**
 * Masks an API key for display, e.g. "sk-ant-abcd1234" -> "sk-ant-...1234".
 * @param {string} key
 * @returns {string}
 */
function maskApiKey(key) {
  if (!key || key.length < 8) return "";
  return `${key.slice(0, 7)}...${key.slice(-4)}`;
}

// Only these exact values are ever interpolated into the system prompt.
// Whitelisting (rather than trying to strip/escape arbitrary text) closes
// off prompt-injection via the language selector, since currentLang is
// normally driven by pill clicks but is treated as untrusted input here.
const ALLOWED_LANGUAGES = ["English", "Español", "Français", "Português", "العربية", "हिन्दी"];

/**
 * Builds the full system prompt for a given language.
 * @param {string} lang
 * @returns {string}
 */
function buildSystemPrompt(lang) {
  const safeLang = ALLOWED_LANGUAGES.includes(lang) ? lang : "English";
  return SYSTEM_PROMPT_BASE + safeLang;
}

/**
 * Formats a Date as a stadium-clock style HH:MM:SS string.
 * @param {Date} date
 * @returns {string}
 */
function formatClock(date) {
  return date.toLocaleTimeString();
}

/**
 * Simple debounce utility — prevents rapid duplicate calls (e.g. double-clicking Send).
 * @param {Function} fn
 * @param {number} wait
 * @returns {Function}
 */
function debounce(fn, wait) {
  let timer = null;
  return function debounced(...args) {
    if (timer) return; // ignore calls while one is pending -> acts as a lock
    timer = setTimeout(() => { timer = null; }, wait);
    fn.apply(this, args);
  };
}

// Export for Node-based unit tests (see tests/app.test.js), no-op in the browser.
if (typeof module !== "undefined" && module.exports) {
  module.exports = {
    CONFIG,
    validateApiKey,
    validateMessage,
    sanitizeText,
    maskApiKey,
    buildSystemPrompt,
    formatClock,
    debounce,
    ALLOWED_LANGUAGES,
  };
}

/* ------------------------------------------------------------------ */
/* 3. DOM WIRING (browser only)                                       */
/* ------------------------------------------------------------------ */

if (typeof window !== "undefined" && typeof document !== "undefined") {
  (function initPitchside() {
    let currentLang = "English";
    let apiKey = "";
    let activeController = null; // AbortController for the in-flight request

    // Try to read a previously saved key. localStorage is used deliberately
    // here (client-only demo, no backend) — see SECURITY.md for the
    // production recommendation (proxy the API key through a server).
    try {
      apiKey = window.localStorage.getItem(CONFIG.STORAGE_KEY) || "";
    } catch (e) {
      apiKey = ""; // localStorage may be unavailable (private mode, etc.)
    }

    const keyStatus = document.getElementById("keyStatus");
    const apiKeyInput = document.getElementById("apiKey");
    const chat = document.getElementById("chat");
    const userInput = document.getElementById("userInput");
    const sendBtn = document.getElementById("sendBtn");
    const charCount = document.getElementById("charCount");

    function refreshKeyStatus() {
      if (apiKey) {
        apiKeyInput.value = maskApiKey(apiKey);
        apiKeyInput.dataset.masked = "true";
        keyStatus.textContent = "✓ Connected — assistant is live.";
        keyStatus.className = "status-line ok";
      } else {
        apiKeyInput.value = "";
        apiKeyInput.dataset.masked = "false";
        keyStatus.textContent = "Not connected yet.";
        keyStatus.className = "status-line";
      }
    }
    refreshKeyStatus();

    // Re-enable editing if the user focuses the (masked) key field again.
    apiKeyInput.addEventListener("focus", () => {
      if (apiKeyInput.dataset.masked === "true") {
        apiKeyInput.value = "";
        apiKeyInput.dataset.masked = "false";
      }
    });

    document.getElementById("saveKey").addEventListener("click", () => {
      const val = apiKeyInput.value.trim();
      const result = validateApiKey(val);
      if (!result.valid) {
        keyStatus.textContent =
          result.reason === "format"
            ? "That doesn't look like a valid Anthropic key (should start with sk-ant-)."
            : "Please paste a valid API key.";
        keyStatus.className = "status-line err";
        return;
      }
      apiKey = val;
      try {
        window.localStorage.setItem(CONFIG.STORAGE_KEY, apiKey);
      } catch (e) {
        // Storage may be full or disabled; key still works for this session.
      }
      refreshKeyStatus();
    });

    document.getElementById("clearKey").addEventListener("click", () => {
      apiKey = "";
      try {
        window.localStorage.removeItem(CONFIG.STORAGE_KEY);
      } catch (e) { /* ignore */ }
      refreshKeyStatus();
    });

    // Language pills
    document.getElementById("langPills").addEventListener("click", (e) => {
      const btn = e.target.closest(".lang-pill");
      if (!btn) return;
      document.querySelectorAll(".lang-pill").forEach((b) => {
        b.classList.remove("active");
        b.setAttribute("aria-pressed", "false");
      });
      btn.classList.add("active");
      btn.setAttribute("aria-pressed", "true");
      currentLang = btn.dataset.lang;
    });

    // Category quick-asks
    document.getElementById("cats").addEventListener("click", (e) => {
      const chip = e.target.closest(".cat-chip");
      if (!chip) return;
      userInput.value = chip.dataset.q;
      updateCharCount();
      sendMessage();
    });

    // Clock (single interval, cheap DOM write, respects reduced-motion users implicitly)
    function tickClock() {
      const clockEl = document.getElementById("clock");
      if (clockEl) clockEl.textContent = formatClock(new Date());
    }
    setInterval(tickClock, 1000);
    tickClock();

    function updateCharCount() {
      if (!charCount) return;
      const len = userInput.value.length;
      charCount.textContent = `${len}/${CONFIG.MAX_MESSAGE_LENGTH}`;
      charCount.style.color = len > CONFIG.MAX_MESSAGE_LENGTH ? "var(--danger)" : "var(--muted)";
    }
    userInput.addEventListener("input", updateCharCount);
    updateCharCount();

    /**
     * Appends a message bubble to the chat log. Always uses textContent
     * (never innerHTML) so model output can never inject markup/scripts.
     */
    function addMessage(text, who) {
      const div = document.createElement("div");
      div.className = "msg " + who;
      div.textContent = text;
      chat.appendChild(div);
      chat.scrollTop = chat.scrollHeight;
      return div;
    }

    async function callClaude(userText) {
      // Cancel any previous in-flight request before starting a new one.
      if (activeController) activeController.abort();
      activeController = new AbortController();
      const timeout = setTimeout(() => activeController.abort(), CONFIG.REQUEST_TIMEOUT_MS);

      const body = {
        model: CONFIG.MODEL,
        max_tokens: CONFIG.MAX_TOKENS,
        system: buildSystemPrompt(currentLang),
        messages: [{ role: "user", content: userText }],
      };

      try {
        const res = await fetch("https://api.anthropic.com/v1/messages", {
          method: "POST",
          headers: {
            "Content-Type": "application/json",
            "x-api-key": apiKey,
            "anthropic-version": "2023-06-01",
            "anthropic-dangerous-direct-browser-access": "true",
          },
          body: JSON.stringify(body),
          signal: activeController.signal,
        });

        if (!res.ok) {
          // Don't leak the raw response body (may echo the key in some proxies) —
          // surface only status + a generic message.
          throw new Error(`API error ${res.status}`);
        }

        const data = await res.json();
        return data.content.map((b) => b.text || "").join("\n").trim();
      } finally {
        clearTimeout(timeout);
      }
    }

    const sendMessage = debounce(async function sendMessageImpl() {
      const raw = userInput.value;
      const text = sanitizeText(raw);
      const validation = validateMessage(text);

      if (!validation.valid) {
        if (validation.reason === "too_long") {
          addMessage(`⚠ Message too long — please keep it under ${CONFIG.MAX_MESSAGE_LENGTH} characters.`, "bot");
        }
        return;
      }

      if (!apiKey) {
        addMessage("⚠ Connect an API key above first, then ask me anything.", "bot");
        return;
      }

      addMessage(text, "user");
      userInput.value = "";
      updateCharCount();
      sendBtn.disabled = true;

      const typingEl = document.createElement("div");
      typingEl.className = "typing";
      typingEl.textContent = "Pitchside is thinking...";
      typingEl.setAttribute("aria-live", "polite");
      chat.appendChild(typingEl);
      chat.scrollTop = chat.scrollHeight;

      try {
        const reply = await callClaude(text);
        typingEl.remove();
        addMessage(reply, "bot");
      } catch (err) {
        typingEl.remove();
        const msg = err.name === "AbortError"
          ? "That request took too long and was cancelled. Please try again."
          : "Something went wrong reaching the assistant. Please try again.";
        const el = addMessage(msg, "bot");
        el.classList.add("error");
      } finally {
        sendBtn.disabled = false;
      }
    }, 400);

    sendBtn.addEventListener("click", sendMessage);
    userInput.addEventListener("keydown", (e) => {
      if (e.key === "Enter") sendMessage();
    });

    /* ---------------- Live Ops panel (mock data, refreshes periodically) ---------------- */
    const OPS_GATES = ["Gate A", "Gate B", "Gate C", "Gate D"];
    function renderOps() {
      const grid = document.getElementById("opsGrid");
      if (!grid) return;
      const congestion = ["good", "warn", "bad"];
      grid.innerHTML = "";
      OPS_GATES.forEach((gate) => {
        const level = congestion[Math.floor(Math.random() * congestion.length)];
        const label = level === "good" ? "Low" : level === "warn" ? "Moderate" : "High";
        const card = document.createElement("div");
        card.className = "ops-card";
        card.innerHTML = `<div class="label">${gate}</div><div class="value ${level}">${label}</div>`;
        grid.appendChild(card);
      });
    }
    renderOps();
    setInterval(renderOps, 15000);
  })();
}
