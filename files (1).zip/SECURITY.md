# Security Notes — Pitchside

## Known limitation: client-side API key

This is a static, no-backend demo. The Anthropic API key the user enters is:
- stored in `localStorage` (persists only in that browser)
- sent directly from the browser to `https://api.anthropic.com`
- never transmitted to any server other than Anthropic's

This is acceptable for a hackathon demo where each user supplies their own
key, but it is **not** a pattern to ship to production, because:
1. Anyone with access to the browser/device can read the key from DevTools → Application → Local Storage.
2. The key is visible in the Network tab on every request.
3. There's no way to scope or rate-limit usage per user.

### Production recommendation
Add a thin backend (Cloudflare Worker, AWS Lambda, or a small Express server)
that:
- holds the real API key as a server-side secret/environment variable
- accepts only the user's message + language from the browser
- calls the Anthropic API server-side and returns just the reply
- applies per-IP or per-session rate limiting

This removes the key from the browser entirely.

## Mitigations already implemented in this version

| Risk | Mitigation |
|---|---|
| XSS via model output or user input | All DOM insertion uses `textContent`, never `innerHTML`, for any user- or model-derived text |
| Prompt injection via the language selector | `buildSystemPrompt()` whitelists the exact 6 language strings the UI offers; anything else falls back to English (see `tests/app.test.js`) |
| Oversized/abusive requests | `MAX_MESSAGE_LENGTH` (500 chars) enforced both in the HTML `maxlength` attribute and in `validateMessage()` |
| Duplicate/spam requests | `debounce()` locks the Send action while a request is in flight; the Send button is also disabled |
| Hung requests | `AbortController` + 20s timeout cancels stalled fetches and frees the UI |
| Malformed/garbage API keys | `validateApiKey()` checks prefix and minimum length before storing |
| Key exposure in the UI | The key input displays a masked value (`sk-ant-...1234`) after saving, not the raw key |
| Clickjacking / unwanted embedding | CSP `frame-ancestors 'none'` |
| Third-party script injection | CSP `script-src 'self'` — only this site's own `js/app.js` may execute |
| `target="_blank"` tab-nabbing | All external links use `rel="noopener noreferrer"` |

## Out of scope for this demo
- Server-side auth / user accounts
- Encryption at rest for the stored key (browser localStorage is plaintext by design)
- CSRF protection (no cookie-based session exists)
